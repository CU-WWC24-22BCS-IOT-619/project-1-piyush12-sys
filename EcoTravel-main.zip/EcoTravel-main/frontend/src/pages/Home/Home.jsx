import React from 'react'
import MainComponents from '../../components/MainComponents/MainComponents'

const Home = () => {
  return (
    <div >
        <MainComponents/>
    </div>
  )
}

export default Home